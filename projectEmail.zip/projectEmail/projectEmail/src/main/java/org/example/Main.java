package org.example;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Main {

        public static class TransfJson {

            private String namePolicy;
            public TransfJson(String namePolicy) {

                this.namePolicy = namePolicy;
            }
            public TransfJson(){}
            public String getNamePolicy() {return namePolicy;}
            public void setNamePolicy(String namePolicy) {this.namePolicy = namePolicy;}
        }

        public static void Scraping() throws IOException {
            String URL = "https://developers.google.com/android/management/reference/rest/v1/enterprises.policies";
            Document doc = Jsoup.connect(URL).get();
            Element table = doc.getElementById("Policy.FIELDS-table");
            Element tbody = table.getElementsByTag("tbody").first();
            List<Element> tr = tbody.getElementsByTag("tr");
            List<TransfJson> tagList = new ArrayList<>();

            for (Element trs : tr) {

                List<Element> attributes = trs.getElementsByTag("td");
                TransfJson transfJson = new TransfJson(attributes.get(0).text());
                tagList.add(transfJson);
            }

            ObjectMapper mapper = new ObjectMapper();
            List<String> Politicas = new ArrayList<String>();

            try {

                for (TransfJson transfJson : tagList) {

                    String Json = mapper.writeValueAsString(transfJson);
                    if (Json.contains("deprecated")) {
                        Politicas.add(Json + "\n");
                    }
                }
                System.out.println(Politicas);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            File arquivo = new File("Politics.txt");
            BufferedReader br = new BufferedReader(new FileReader(arquivo));
            System.out.println();
            if(br.readLine() == null){
                System.out.println("Arquivo vazio");
                PrintWriter escrita = new PrintWriter(arquivo);
                escrita.print(Politicas);
                escrita.close();
                System.out.println("Arquivo criado");
            } else {
                boolean envioDeEmail = false;
                System.out.println("Arquivo existente");
                String oldPoliticas = new Scanner(new File("Politics.txt")).useDelimiter("\\\\Z").next();
                if(oldPoliticas.equals(Politicas.toString())){
                    envioDeEmail = false;
                    System.out.println(envioDeEmail);
                } else {
                    PrintWriter escrita = new PrintWriter(arquivo);
                    escrita.print(Politicas);
                    escrita.close();
                    envioDeEmail = true;
                    System.out.println(envioDeEmail);
                }
            }
        }

    public static void main(String[] args) {

        try {
            Scraping();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}